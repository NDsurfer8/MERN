// import logo from './logo.svg';
import './App.css';
import Hooked from './components/Hooked';



const App = () => {
  return (
    <div className="App">
      <Hooked />
    </div>
  );
}

export default App;
