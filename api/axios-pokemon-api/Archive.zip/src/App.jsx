// import logo from './logo.svg';
import axios from 'axios';
import './App.css';
import Pokemon from './components/Pokemon';

const App = () => {
  return (
    <div className="App">
      <Pokemon/>
    </div>
  );
}

export default App;
